import React from "react";
import { Link } from "react-router-dom";


const Home = () => {
  return (
    <>
      <nav className="navbar" role="navigation" aria-label="main navigation">
        <div className="navbar-brand">
          <a className="navbar-item" href="/">
            <img
              src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcToe5oBRODC80yLLssXNvXQ7pkiNMH0agfhHA&s"
              width="150"
              height="28"
              alt="GFG"
            />
          </a>

          <a
                    role="button"
                    className={`navbar-burger burger ${isActive ? 'is-active' : ''}`}
                    aria-label="menu"
                    aria-expanded="false"
                    onClick={toggleNav}
                >
                    <span aria-hidden="true"></span>
                    <span aria-hidden="true"></span>
                    <span aria-hidden="true"></span>
                </a>
        </div>
        <div className="navbar-menu">
          <div className="navbar-start">
            <Link className="navbar-item has-text-weight-semibold" to="classes">FITNESS & PROGRAMS</Link>
            <Link className="navbar-item has-text-weight-semibold">CLASS SCHEDUEL</Link>
            <Link className="navbar-item has-text-weight-semibold">NEWS</Link>
            <Link className="navbar-item has-text-weight-semibold">SHEDULE A TOUR</Link>
            <Link className="navbar-item has-text-weight-semibold">BECOME A MEMBER</Link>
          </div>
          <div className="navbar-end">
            <Link className="navbar-item has-text-weight-bold">LOG IN</Link>
            <Link className="navbar-item has-text-weight-bold">SIGN UP</Link>
            <Link className="navbar-item has-text-weight-bold">LOG OUT</Link>
          </div>
        </div>
      </nav>
    </>
  );
};

export default Home;
