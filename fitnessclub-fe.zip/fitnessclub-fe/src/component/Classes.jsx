import Footer from "./Footer";
import Header from "./Header";


const Classes = ()=>{
    return(
        <div>
            <Header/>
            <p>this is a classes page</p>
            <Footer/>
        </div>
    );
}

export default Classes;